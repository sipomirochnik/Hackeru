package hysb.com.example.serjofactory.security;

import android.os.Bundle;
import androidx.annotation.NonNull;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import androidx.fragment.app.Fragment;
import androidx.appcompat.app.AppCompatActivity;
import android.view.MenuItem;

public class MainActivity extends AppCompatActivity {



    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {

            Fragment f = null;
            switch (item.getItemId()) {
                case R.id.navigation_week:
                    f = new WeekOrder();
                    break;
                case R.id.navigation_shift:
                    f = new SwitchShift();
                    break;
                case R.id.navigation_contact:
                    f = new Contacts();
                    break;
            }
            if (f !=null)
            getSupportFragmentManager().beginTransaction().replace(R.id.container, f).commit();
         return true;
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        BottomNavigationView navigation = (BottomNavigationView) findViewById(R.id.navigation);
        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);



        WeekOrder f = new WeekOrder();
        getSupportFragmentManager().beginTransaction().replace(R.id.container, f).commit();

    }

}
