package hysb.com.example.serjofactory.security;

public class Employee {

    private String employeeName;
    private String employeePhone;

    public Employee(String employeeName, String employeePhone) {
        this.employeeName = employeeName;
        this.employeePhone = employeePhone;
    }

    public String getEmployeeName() {
        return employeeName;
    }

    public void setEmployeeName(String employeeName) {
        this.employeeName = employeeName;
    }

    public String getEmployeePhone() {
        return employeePhone;
    }

    public void setEmployeePhone(String employeePhone) {
        this.employeePhone = employeePhone;
    }

    @Override
    public String toString() {
        return "Employee{" +
                "employeeName='" + employeeName + '\'' +
                ", employeePhone='" + employeePhone + '\'' +
                '}';
    }
}
