package hysb.com.example.serjofactory.security;

public class EmployeeAdapter {

//    class EmployeeAdapter extends RecyclerView.ViewHolder{
//        public EmployeeAdapter(@NonNull View itemView) {
//            super(itemView);
//        }
//    }
}
